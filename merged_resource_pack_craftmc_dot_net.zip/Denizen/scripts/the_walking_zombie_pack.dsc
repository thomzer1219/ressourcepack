commonwealth_armor_wearing:
    type: world
    debug: false
    events:
        on ZOMBIE damages PLAYER flagged:zombie_zero_damage:
        	- if <util.random_chance[75]> == true:
        		- playsound sound:ENTITY_SHULKER_HURT_CLOSED <player> sound_category:MASTER pitch:1.2 volume:0.8
        		- determine CANCELLED
commonwealth_helmet:
    type: item
    material: white_stained_glass
    display name: "<&r>Commonwealth Helmet"
    lore:
	- "<empty>"
    - "<&e>We are the power!"
    - "<&e>We are the protective ones!"
    - "<&e>We are the Commonwealth!"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Equip me to be in power"
	- "<&c>like a Commonwealth Soldier!"
	- "<&c>When helmet is equipped, you"
	- "<&c>gain a chance that walkers"
	- "<&c>take zero damage to you..."
    mechanisms:
        custom_model_data: 11520
        attribute_modifiers:
            generic_armor:
                1:
                    operation: add_number
                    amount: 3
                    slot: head
            generic_armor_toughness:
                1:
                    operation: add_number
                    amount: 2
                    slot: head
commonwealth_helmet_place:
    type: world
    debug: false
    events:
        on player places commonwealth_helmet:
            - determine CANCELLED
commonwealth_helmet_wearing:
    type: world
    debug: false
    events:
        on PLAYER equips commonwealth_helmet:
            - wait 1t
            - playsound sound:ITEM_ARMOR_EQUIP_NETHERITE <player> sound_category:MASTER
			- playsound sound:ENTITY_PLAYER_BREATH <player> sound_category:MASTER pitch:2.0 volume:0.8
			- if <player.has_equipped[commonwealth_chestplate|commonwealth_leggings|commonwealth_boots]> == false:
            	- wait 2t
            	- flag player zombie_zero_damage
        on PLAYER unequips commonwealth_helmet:
        	- if <player.has_equipped[commonwealth_chestplate|commonwealth_leggings|commonwealth_boots]> == false:
            	- wait 1t
            	- flag player zombie_zero_damage:!
commonwealth_helmet_equip:
    type: world
    debug: false
    events:
        on PLAYER right clicks AIR with:commonwealth_helmet:
			- if <player.has_equipped[*_helmet|carved_pumpkin|commonwealth_helmet|exo_mask|damaged_exo_mask|whisperers_mask]> == false:
				- ratelimit <player> 20t
				- take iteminhand
				- equip <player> head:commonwealth_helmet
			- else:
				- determine CANCELLED
commonwealth_chestplate:
    type: item
    material: diamond_chestplate
    display name: "<&r>Commonwealth Chestplate"
    lore:
	- "<empty>"
    - "<&e>We are the power!"
    - "<&e>We are the protective ones!"
    - "<&e>We are the Commonwealth!"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Equip me to be in power"
	- "<&c>like a Commonwealth Soldier!"
	- "<&c>When chestplate is equipped, you"
	- "<&c>gain a chance that walkers"
	- "<&c>take zero damage to you..."
    mechanisms:
        custom_model_data: 11520
commonwealth_chestplate_wearing:
    type: world
    debug: false
    events:
        on PLAYER equips commonwealth_chestplate:
            - wait 1t
            - playsound sound:ITEM_ARMOR_EQUIP_NETHERITE <player> sound_category:MASTER
			- if <player.has_equipped[commonwealth_helmet|commonwealth_leggings|commonwealth_boots|mercerwealth_helmet|mercerwealth_leggings|mercerwealth_boots]> == false:
				- wait 2t
            	- flag player zombie_zero_damage
        on PLAYER unequips commonwealth_chestplate:
			- if <player.has_equipped[commonwealth_helmet|commonwealth_leggings|commonwealth_boots|mercerwealth_helmet|mercerwealth_leggings|mercerwealth_boots]> == false:
            	- wait 1t
            	- flag player zombie_zero_damage:!
commonwealth_leggings:
    type: item
    material: diamond_leggings
    display name: "<&r>Commonwealth Leggings"
    lore:
	- "<empty>"
    - "<&e>We are the power!"
    - "<&e>We are the protective ones!"
    - "<&e>We are the Commonwealth!"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Equip me to be in power"
	- "<&c>like a Commonwealth Soldier!"
	- "<&c>When leggings is equipped, you"
	- "<&c>gain a chance that walkers"
	- "<&c>take zero damage to you..."
    mechanisms:
        custom_model_data: 11520
commonwealth_leggings_wearing:
    type: world
    debug: false
    events:
        on PLAYER equips commonwealth_leggings:
            - wait 1t
            - playsound sound:ITEM_ARMOR_EQUIP_NETHERITE <player> sound_category:MASTER
			- if <player.has_equipped[commonwealth_helmet|commonwealth_chestplate|commonwealth_boots|mercerwealth_helmet|mercerwealth_chestplate|mercerwealth_boots]> == false:
				- wait 2t
            	- flag player zombie_zero_damage
        on PLAYER unequips commonwealth_leggings:
			- if <player.has_equipped[commonwealth_helmet|commonwealth_chestplate|commonwealth_boots|mercerwealth_helmet|mercerwealth_chestplate|mercerwealth_boots]> == false:
            	- wait 1t
            	- flag player zombie_zero_damage:!
commonwealth_boots:
    type: item
    material: diamond_boots
    display name: "<&r>Commonwealth Boots"
    lore:
	- "<empty>"
    - "<&e>We are the power!"
    - "<&e>We are the protective ones!"
    - "<&e>We are the Commonwealth!"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Equip me to be in power"
	- "<&c>like a Commonwealth Soldier!"
	- "<&c>When boots is equipped, you"
	- "<&c>gain a chance that walkers"
	- "<&c>take zero damage to you..."
    mechanisms:
        custom_model_data: 11520
commonwealth_boots_wearing:
    type: world
    debug: false
    events:
        on PLAYER equips commonwealth_boots:
            - wait 1t
            - playsound sound:ITEM_ARMOR_EQUIP_NETHERITE <player> sound_category:MASTER
			- if <player.has_equipped[commonwealth_helmet|commonwealth_chestplate|commonwealth_leggings|mercerwealth_helmet|mercerwealth_chestplate|mercerwealth_leggings]> == false:
				- wait 2t
            	- flag player zombie_zero_damage
        on PLAYER unequips commonwealth_boots:
			- if <player.has_equipped[commonwealth_helmet|commonwealth_chestplate|commonwealth_leggings|mercerwealth_helmet|mercerwealth_chestplate|mercerwealth_leggings]> == false:
            	- wait 1t
            	- flag player zombie_zero_damage:!

mercerwealth_armor_wearing:
    type: world
    debug: false
    events:
        on ZOMBIE damages PLAYER flagged:zombie_zero_damage_mercer:
        	- if <util.random_chance[90]> == true:
        		- playsound sound:ENTITY_SHULKER_HURT_CLOSED <player> sound_category:MASTER pitch:1.2 volume:0.8
        		- determine CANCELLED
mercerwealth_chestplate:
    type: item
    material: diamond_chestplate
    display name: "<&r>Commander's Chestplate"
    lore:
	- "<empty>"
    - "<&e>We are the kind ones!"
    - "<&e>We are the protective ones!"
    - "<&e>We are the Commonwealth!"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Red. The color of the power,"
	- "<&c>but you must also be a chosen"
	- "<&c>for this important role of leader."
    mechanisms:
        custom_model_data: 11521
mercerwealth_chestplate_wearing:
    type: world
    debug: false
    events:
        on PLAYER equips mercerwealth_chestplate:
            - wait 1t
            - playsound sound:ITEM_ARMOR_EQUIP_NETHERITE <player> sound_category:MASTER
			- if <player.has_equipped[commonwealth_helmet|commonwealth_leggings|commonwealth_boots|mercerwealth_helmet|mercerwealth_leggings|mercerwealth_boots]> == false:
				- wait 2t
            	- flag player zombie_zero_damage_mercer
        on PLAYER unequips mercerwealth_chestplate:
			- if <player.has_equipped[commonwealth_helmet|commonwealth_leggings|commonwealth_boots|mercerwealth_helmet|mercerwealth_leggings|mercerwealth_boots]> == false:
            	- wait 1t
            	- flag player zombie_zero_damage_mercer:!
mercerwealth_leggings:
    type: item
    material: diamond_leggings
    display name: "<&r>Commander's Leggings"
    lore:
	- "<empty>"
    - "<&e>We are the kind ones!"
    - "<&e>We are the protective ones!"
    - "<&e>We are the Commonwealth!"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Red. The color of the power,"
	- "<&c>but you must also be a chosen"
	- "<&c>for this important role of leader."
    mechanisms:
        custom_model_data: 11521
mercerwealth_leggings_wearing:
    type: world
    debug: false
    events:
        on PLAYER equips mercerwealth_leggings:
            - wait 1t
            - playsound sound:ITEM_ARMOR_EQUIP_NETHERITE <player> sound_category:MASTER
			- if <player.has_equipped[commonwealth_helmet|commonwealth_chestplate|commonwealth_boots|mercerwealth_helmet|mercerwealth_chestplate|mercerwealth_boots]> == false:
				- wait 2t
            	- flag player zombie_zero_damage_mercer
        on PLAYER unequips mercerwealth_leggings:
        	- if <player.has_equipped[commonwealth_helmet|commonwealth_chestplate|commonwealth_boots|mercerwealth_helmet|mercerwealth_chestplate|mercerwealth_boots]> == false:
            	- wait 1t
            	- flag player zombie_zero_damage_mercer:!
mercerwealth_boots:
    type: item
    material: diamond_boots
    display name: "<&r>Commander's Boots"
    lore:
	- "<empty>"
    - "<&e>We are the kind ones!"
    - "<&e>We are the protective ones!"
    - "<&e>We are the Commonwealth!"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Red. The color of the power,"
	- "<&c>but you must also be a chosen"
	- "<&c>for this important role of leader."
    mechanisms:
        custom_model_data: 11521
mercerwealth_boots_wearing:
    type: world
    debug: false
    events:
        on PLAYER equips mercerwealth_boots:
            - wait 1t
            - playsound sound:ITEM_ARMOR_EQUIP_NETHERITE <player> sound_category:MASTER
			- if <player.has_equipped[commonwealth_helmet|commonwealth_chestplate|commonwealth_leggings|mercerwealth_helmet|mercerwealth_chestplate|mercerwealth_leggings]> == false:
				- wait 2t
            	- flag player zombie_zero_damage_mercer
        on PLAYER unequips mercerwealth_boots:
        	- if <player.has_equipped[commonwealth_helmet|commonwealth_chestplate|commonwealth_leggings|mercerwealth_helmet|mercerwealth_chestplate|mercerwealth_leggings]> == false:
            	- wait 1t
            	- flag player zombie_zero_damage_mercer:!

whisperers_mask_script:
    type: world
    debug: false
    events:
        on player right clicks ZOMBIE_HEAD with:SHEARS:
            - determine passively cancelled
            - playsound sound:ENTITY_SHEEP_SHEAR sound_category:MASTER <player>
            - modifyblock <context.location> block_type:player_head
            - adjust <context.location> skull_skin:df233cdb-06a0-4e00-aded-23b67fc6cdaa|eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvY2UyZmJhZWYzMzFlOTA1ZDRiMmM1ZTY5MzVkZWY5NGM4ZTRjMzJlY2EwMzE3ZDE0M2E0NDExOTNhZThmODI0ZSJ9fX0=
            - wait 5t
            - playsound sound:ENTITY_SHEEP_SHEAR sound_category:MASTER <player>
            - wait 3t
            - playsound sound:ENTITY_SHEEP_SHEAR sound_category:MASTER <player>
            - wait 5t
            - playsound sound:ENTITY_SHEEP_SHEAR sound_category:MASTER <player>
            - wait 10t
            - playsound sound:ENTITY_SHEEP_SHEAR sound_category:MASTER <player>
            - wait 5t
            - if <util.random_chance[60]> == true:
                - drop whisperers_mask <context.location.block>
                - narrate "<&a><bold>Whoa! <&7>You managed to cut out the zombie mask."
            - else:
                - narrate "<&c><bold>Aghgg! <&7>You failed to cut out the zombie mask."
            - adjust <context.location.block> block_type:skeleton_skull
zombie_player_head:
    type: item
    material: player_head
    display name: "<&e>Damaged Zombie Head"
    mechanisms:
        skull_skin: df233cdb-06a0-4e00-aded-23b67fc6cdaa|eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvY2UyZmJhZWYzMzFlOTA1ZDRiMmM1ZTY5MzVkZWY5NGM4ZTRjMzJlY2EwMzE3ZDE0M2E0NDExOTNhZThmODI0ZSJ9fX0=
whisperers_mask:
    type: item
    material: white_stained_glass
    display name: "<&r>Whisperers Mask"
    lore:
	- "<empty>"
    - "<&e>Really stinky mask of dead walker,"
    - "<&e>but really protective against them itself!"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Equip me to be invulnerable"
	- "<&c>to all walkers in this world!"
	- "<&c>Beware! If you hit walkers they"
	- "<&c>came after you! (in your radius)"
    mechanisms:
        custom_model_data: 11521
        attribute_modifiers:
            generic_armor:
                1:
                    operation: add_number
                    amount: 1
                    slot: head
whisperers_mask_place:
    type: world
    debug: false
    events:
        on player places whisperers_mask:
            - determine CANCELLED
whisperers_mask_wearing:
    type: world
    debug: false
    events:
        on PLAYER equips whisperers_mask:
            - wait 1t
            - playsound sound:ITEM_ARMOR_EQUIP_GENERIC <player> sound_category:MASTER
            - cast CONFUSION amplifier:0 duration:10s hide_particles no_ambient
            - flag player zombie_ignore
        on PLAYER unequips whisperers_mask:
            - wait 1t
            - cast DAMAGE_RESISTANCE remove <player>
            - flag player zombie_ignore:!
        on ZOMBIE targets PLAYER flagged:zombie_ignore:
        	- determine CANCELLED
        on ZOMBIE damaged by PLAYER flagged:zombie_ignore:
        	- flag player zombie_ignore:!
        	- wait 40t
        	- flag player zombie_ignore
whisperers_mask_equip:
    type: world
    debug: false
    events:
        on PLAYER right clicks AIR with:whisperers_mask:
			- if <player.has_equipped[*_helmet|carved_pumpkin|commonwealth_helmet|exo_mask|damaged_exo_mask|whisperers_mask]> == false:
				- ratelimit <player> 20t
				- take iteminhand
				- equip <player> head:whisperers_mask
			- else:
				- determine CANCELLED

daryl_crossbow:
    type: item
    material: crossbow
    display name: "<&r>Daryl Crossbow"
    lore:
	- "<empty>"
    - "<&e>Can you achieve higher amount of"
    - "<&e>killed walkers than Daryl Dixon?"
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Become a real hunter with this"
	- "<&c>fast and really advanced crossbow..."
    mechanisms:
        custom_model_data: 11520
    #enchantments:
    	#- quick_charge:3

whisperers_knife:
    type: item
    material: iron_sword
    display name: "<&r>Whisperers Knife"
    lore:
	- "<empty>"
    - "<&e>Bloody and yet murdering tool of"
    - "<&e>those who is psychically on the ground."
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>It's not recommended to use it."
	- "<&c>It can cause a high confusion..."
    mechanisms:
        custom_model_data: 11520
        attribute_modifiers:
            generic_attack_damage:
                1:
                    operation: add_number
                    amount: 6
                    slot: hand
            generic_attack_speed:
                1:
                    operation: add_number
                    amount: -2
                    slot: hand
whisperers_knife_hit:
    type: world
    debug: false
    events:
        on PLAYER left clicks AIR with:whisperers_knife:
            - if <util.random_chance[33]> == true:
                - ratelimit <player> 160t
                - determine passively cancelled
                - wait 2t
                - cast CONFUSION amplifier:1 duration:8s hide_particles no_ambient

michonne_katana:
    type: item
    material: diamond_sword
    display name: "<&r>Michonne Katana"
    lore:
	- "<empty>"
    - "<&e>I've never seen a sharper katana."
    - "<&e>Those walkers must cry, when"
    - "<&e>they see this fabulous blade."
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Slice those walkers like nothing..."
    mechanisms:
        custom_model_data: 11520
        attribute_modifiers:
            generic_attack_damage:
                1:
                    operation: add_number
                    amount: 10
                    slot: hand
            generic_attack_speed:
                1:
                    operation: add_number
                    amount: -2
                    slot: hand
michonne_katana_hit:
    type: world
    debug: false
    events:
        on PLAYER left clicks AIR with:michonne_katana:
            - ratelimit <player> 5t
            - determine passively cancelled
            - wait 2t
            - playsound pitch:1.2 sound:ITEM_TRIDENT_THROW <player> sound_category:MASTER

negan_lucille:
    type: item
    material: diamond_sword
    display name: "<&r>Negan Lucille"
    lore:
	- "<empty>"
    - "<&e>Whistling will improve power of"
    - "<&e>this legendary strentghened bat."
    - "<empty>"
	- "<&e>You can customize this text lore"
	- "<&e>as much as you like, as well as the"
	- "<&e>item material and custom model data."
    - "<empty>"
	- "<&c>Smash those walkers heads!"
    mechanisms:
        custom_model_data: 11521
        attribute_modifiers:
            generic_attack_damage:
                1:
                    operation: add_number
                    amount: 16
                    slot: hand
            generic_attack_speed:
                1:
                    operation: add_number
                    amount: -3
                    slot: hand
negan_lucille_hit:
    type: world
    debug: false
    events:
        on PLAYER left clicks AIR with:negan_lucille:
            - ratelimit <player> 10t
            - determine passively cancelled
            - wait 2t
            - playsound pitch:0.2 sound:ITEM_TRIDENT_HIT <player> sound_category:MASTER
        on PLAYER right clicks AIR with:negan_lucille:
            - ratelimit <player> 150t
            - determine passively cancelled
            - wait 2t
            - playsound pitch:1.5 volume:2 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:1.5 volume:2 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:1.5 volume:2 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:3.5 volume:8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:3.5 volume:8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - cast INCREASE_DAMAGE amplifier:1 duration:2s hide_particles no_ambient
            - playsound pitch:3.5 volume:8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:3.5 volume:8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:3.5 volume:8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:3.5 volume:8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:3.5 volume:4 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:3.5 volume:4 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:3.5 volume:4 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:3.5 volume:4 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:3.5 volume:4 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:3.5 volume:4 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:3.5 volume:0.8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:3.5 volume:0.8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:3.5 volume:0.8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:3.5 volume:0.8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - cast INCREASE_DAMAGE amplifier:1 duration:2s hide_particles no_ambient
            - playsound pitch:3.5 volume:0.8 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 5t
            - playsound pitch:1.5 volume:0.5 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:1.5 volume:0.5 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:1.5 volume:0.1 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:1.5 volume:0.1 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:1.5 volume:0.1 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:1.5 volume:0.1 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 2t
            - playsound pitch:1.5 volume:0.1 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER
            - wait 1t
            - playsound pitch:1.5 volume:0.1 sound:ENTITY_PARROT_AMBIENT <player> sound_category:MASTER

whisperers_script:
    type: world
    debug: true
    events:
        on mythicmob Whisperer1 death:
            - if <util.random_chance[33]> == true:
                - drop whisperers_knife quantity:<util.int[1]> <context.entity.location>
            - else if <util.random_chance[10]> == true:
                - drop whisperers_mask quantity:<util.int[1]> <context.entity.location>
        on mythicmob Whisperer2 death:
            - if <util.random_chance[33]> == true:
                - drop whisperers_knife quantity:<util.int[1]> <context.entity.location>
            - else if <util.random_chance[10]> == true:
                - drop whisperers_mask quantity:<util.int[1]> <context.entity.location>
        on mythicmob Whisperer1Fellas death:
            - if <util.random_chance[33]> == true:
                - drop whisperers_knife quantity:<util.int[1]> <context.entity.location>
            - else if <util.random_chance[10]> == true:
                - drop whisperers_mask quantity:<util.int[1]> <context.entity.location>
        on mythicmob Whisperer2Fellas death:
            - if <util.random_chance[33]> == true:
                - drop whisperers_knife quantity:<util.int[1]> <context.entity.location>
            - else if <util.random_chance[10]> == true:
                - drop whisperers_mask quantity:<util.int[1]> <context.entity.location>